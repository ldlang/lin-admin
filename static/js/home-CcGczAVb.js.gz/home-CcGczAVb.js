import{o as _,e as d}from"./element-plus-BLeghT3y.js";import{d as h,r as u,o as s,c as n,S as r,V as a,a as e,T as f,aa as v,u as c,W as x,_ as p,Q as g}from"./@vue-8NkTQehK.js";import"./lodash-es-Bwfjn3gr.js";import"./async-validator-DKvM95Vc.js";import"./@vueuse-Bw2xgJDF.js";import"./@element-plus-Ue8JEva9.js";import"./dayjs-Bkv9doWi.js";import"./crypto-js-aX0Vy_I7.js";import"./@ctrl-r5W6hzzQ.js";import"./@sxzz-D9SI2xQl.js";import"./normalize-wheel-es-B6fDCfyv.js";const k={class:"flex"},w=e("div",{class:"flex mx-10 flex-col justify-between"},[e("h3",null,"学海无涯，苦乐自知。"),e("div",{class:"text-15 mt-5"},"苦，乃求学之必经之路。乐，为求学之甘果。攻克难题，掌握新技， 喜悦与成就感如泉水涌，那份满足与自豪，非物质之享所能及。 ")],-1),y=e("h2",{class:"text-center"},"人生三大境界",-1),B={class:"flex"},W=h({__name:"home",setup(C){const o=u([{title:"昨夜西风凋碧树，独上高楼，望尽天涯路。",paraphrase:`
    昨天夜里秋风萧瑟，凋零了树木。我独自登上高楼，
    遥望那消失于天涯尽头的道路。
    要想成功必须要树立好自己的目标，人生之路本来就是风雨交加，
    坎坷难行，而且充满了孤独，高处不胜寒。人要想成功，
    只有“独上高楼，望尽天涯路”，高瞻远瞩，看到别人看不到的地方，
    明确自己的目标与方向，独辟蹊径。`},{title:"衣带渐宽终不悔 为伊消得人憔悴的意思。",paraphrase:`我虽日渐消瘦却决不懊悔，为了你，
    我情愿一身憔悴。成大事业、大学问绝不是轻而易举的，
    会遇到艰难险阻，必须要有一种锲而不舍的坚毅性格和执
    着态度，废寝忘食，攻坚克难，经过辛勤的努力，直至人瘦带宽也不后悔。`},{title:"众里寻他千百度，蓦然回首，那人却在，灯火阑珊处。",paraphrase:`我在人海中寻找了她千百回，不曾想不经意间一回头，
    却在灯火零落处发现了她。成大事业、大学问必须孜孜以求，
    反复追寻、研究，下足功夫，在足够的积累之后，必然由量变到质变，
    不经意间已追逐到了，成功了。`}]);return(E,V)=>{const m=_,t=d;return s(),n("div",null,[r(t,{shadow:"hover"},{default:a(()=>[e("div",k,[r(m,{size:"large",class:"shrink-0",src:"/lin-admin/image/avatar.jpg"}),w])]),_:1}),r(t,{shadow:"hover",class:"my-10"},{default:a(()=>[y]),_:1}),e("div",B,[(s(!0),n(f,null,v(c(o),(l,i)=>(s(),x(t,{key:i,shadow:"hover",class:g(["flex-1",{"mr-10":i<c(o).length-1}])},{header:a(()=>[e("h3",null,p(l.title),1)]),default:a(()=>[e("div",null,p(l.paraphrase),1)]),_:2},1032,["class"]))),128))])])}}});export{W as default};
